#ifndef _ALL_H_
#define _ALL_H_

#include "sys_header.h"
#include<cassert>
#include"DisWin.h"
// #include"Tree.h"
// #include"Map.h"
// #include"Log.h"
#include"Init.h"
#include"macro.h"


#endif // _ALL_H_