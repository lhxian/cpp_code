#ifndef _INIT_H_
#define _INIT_H_

#include<Windows.h>

void Init_Image();
// void InitAll(HINSTANCE p_inst,int cmdshow,HANDLE p_mutex = 0);
void Init_Game();
// void CloseAll();
void Close_Game();


#endif // _INIT_H_