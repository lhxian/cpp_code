#ifndef _CONSTV_H_
#define _CONSTV_H_
#include<windows.h>
extern const INT32 disrect_move_dires[4][2];

extern const INT32 dires[4][2];
extern const WCHAR* global_num_string;
#endif // _CONSTV_H_