// #pragma once
#ifndef _SYS_HEADER_H_
#define _SYS_HEADER_H_

#include<Windows.h>
#include<gdiplus.h>
#include<cassert>
namespace gs = Gdiplus;
#endif // _SYS_HEADER_H_